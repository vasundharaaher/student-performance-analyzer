from flask import Flask, request, jsonify
from flask_cors import CORS  # Import CORS
import os
import pytesseract
from PIL import Image
import cv2
import numpy as np
import fitz  # PyMuPDF
from pdf2image import convert_from_path
import json
from docx import Document  # Import python-docx

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

app.config['UPLOAD_FOLDER'] = 'uploads/'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'jpeg', 'jpg', 'png', 'pdf', 'docx'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB limit

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'File type not allowed'}), 400
    
    if len(file.read()) > MAX_FILE_SIZE:
        return jsonify({'error': 'File size exceeds limit (5MB)'}), 400
    file.seek(0)  # Reset file pointer after reading size
    
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(file_path)
    
    return jsonify({'message': 'File uploaded successfully', 'file_path': file_path})


@app.route('/extract_text', methods=['POST'])
def extract_text():
    data = request.json
    file_path = data.get('file_path')

    if not file_path or not os.path.exists(file_path):
        return jsonify({'error': 'Invalid file path'}), 400

    text = ""

    if file_path.lower().endswith('.pdf'):
        with fitz.open(file_path) as doc:
            for page in doc:
                text += page.get_text("text") + "\n"

        if not text.strip():
            images = convert_from_path(file_path)
            for img in images:
                text += pytesseract.image_to_string(img) + "\n"

    elif file_path.lower().endswith('.docx'):
        doc = Document(file_path)
        text = "\n".join([para.text for para in doc.paragraphs])

    elif file_path.lower().endswith(('.jpeg', '.jpg', '.png')):
        image = Image.open(file_path)
        text = pytesseract.image_to_string(image)

    else:
        return jsonify({'error': 'Unsupported file format'}), 400

    # Save extracted text to a JSON file
    json_path = file_path.rsplit('.', 1)[0] + ".json"
    with open(json_path, "w", encoding="utf-8") as json_file:
        json.dump({"extracted_text": text}, json_file, indent=4)

    return jsonify({'extracted_text': text, 'json_file': json_path})

def preprocess_image(image_path):
    # Ensure the file exists
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"File not found: {image_path}")

    # Ensure the file is an image
    if not image_path.lower().endswith(('.jpeg', '.jpg', '.png')):
        raise ValueError(f"Invalid file type for preprocessing: {image_path}")

    # Read the image
    image = cv2.imread(image_path)
    if image is None:
        raise ValueError(f"Error reading image file: {image_path}")

    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply Gaussian blur
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Apply thresholding for better clarity
    _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # Save processed image
    processed_path = image_path.replace(".png", "_processed.png").replace(".jpg", "_processed.jpg").replace(".jpeg", "_processed.jpeg")
    cv2.imwrite(processed_path, thresh)

    return processed_path


@app.route('/preprocess', methods=['POST'])
def preprocess():
    data = request.json
    file_path = data.get('file_path')

    if not file_path or not os.path.exists(file_path):
        return jsonify({'error': 'Invalid file path'}), 400

    # Ensure it's an image before processing
    if not file_path.lower().endswith(('.jpeg', '.jpg', '.png')):
        return jsonify({'error': 'Only image files can be preprocessed'}), 400

    try:
        processed_path = preprocess_image(file_path)
        return jsonify({'processed_file': processed_path})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True)
