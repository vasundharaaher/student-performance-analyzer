document.getElementById("uploadForm").addEventListener("submit", function(event) {
    event.preventDefault();  // Prevent page refresh
    uploadFile();
});
function uploadFile() {
    const fileInput = document.getElementById("fileInput");
    const file = fileInput.files[0];

    console.log("Selected File:", file);

    if (!file) {
        alert("Please select a file.");
        return;
    }
    
    const formData = new FormData();
    formData.append("file", file);

    fetch("http://127.0.0.1:5000/upload", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        console.log("Upload Response:", data);

        if (data.error) {
            alert("Error: " + data.error);
        } else {
            document.getElementById("uploadStatus").innerText = data.message;
            localStorage.setItem("filePath", data.file_path);
        }
    })
    .catch(error => console.error("Error:", error));
}

function extractText() {
    const filePath = localStorage.getItem("filePath");
    if (!filePath) {
        alert("No file uploaded.");
        return;
    }
    
    fetch("http://127.0.0.1:5000/extract_text", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ file_path: filePath })
    })
    .then(response => response.json())
    .then(data => {
        console.log("Extracted Text Response:", data);
        if (data.error) {
            alert("Error: " + data.error);
        } else {
            document.getElementById("extractedText").innerText = data.extracted_text;
            localStorage.setItem("extractedText", JSON.stringify(data.extracted_text)); 

            // Download JSON file
            if (data.json_file) {
                const jsonLink = document.createElement("a");
                jsonLink.href = "http://127.0.0.1:5000/" + data.json_file;
                jsonLink.download = "extracted_text.json";
                jsonLink.innerText = "Download Extracted Text";
                document.body.appendChild(jsonLink);
            }
        }
    })
    .catch(error => console.error("Error:", error));
}

function preprocessImage() {
    const filePath = localStorage.getItem("filePath");
    if (!filePath) {
        alert("No file uploaded.");
        return;
    }
    
    fetch("http://127.0.0.1:5000/preprocess", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ file_path: filePath })
    })
    .then(response => response.json())
    .then(data => {
        console.log("Preprocess Response:", data);
        if (data.error) {
            alert("Error: " + data.error);
        } else {
            document.getElementById("preprocessStatus").innerText = "Image preprocessed successfully.";
            localStorage.setItem("preprocessedFilePath", data.processed_file);
        }
    })
    .catch(error => console.error("Error:", error));
}
